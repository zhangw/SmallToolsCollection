ThermoCtripLogin
==================
A web page that used to single login the Ctrip website in ThermoFisher.
